# Huggins Wood Floor Specialist — Eco-Friendly Refinishing (NYC)

Next.js + Tailwind landing page ready to deploy on Vercel.

## Getting Started (local)
```bash
npm install
npm run dev
```
Visit http://localhost:3000

## Deploy on Vercel
Import this repo in Vercel and deploy with defaults.

## Structure
```
/pages/_app.jsx      # imports Tailwind
/pages/index.jsx     # landing page
/styles/globals.css  # Tailwind CSS
/tailwind.config.js
/postcss.config.js
/package.json
```
