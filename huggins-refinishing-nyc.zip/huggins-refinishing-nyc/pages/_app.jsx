export default function MyApp({ Component, pageProps }) {
  return <Component {...pageProps} />;
}
import "../styles/globals.css";
